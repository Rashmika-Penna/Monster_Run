# Health Bar
Project files for our tutorial on how to create a health bar in Unity.



Check out our [YouTube Channel](http://youtube.com/brackeys) for more tutorials.